import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetAllProjectsComponent } from './get-all-projects/get-all-projects.component';
import { AddProjectComponent } from './add-project/add-project.component';
import { SearchProjectComponent } from './search-project/search-project.component';
import { UpdateProjectComponent } from './update-project/update-project.component';


const routes: Routes = [
  { path: 'Display', component: GetAllProjectsComponent },
  { path: 'Add', component: AddProjectComponent },
  { path: 'Search', component: SearchProjectComponent },
  { path: 'Update', component: UpdateProjectComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
